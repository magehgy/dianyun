#include "C_OpenCV.h"


int test()
{

    // ����ԭʼͼ��
    cv::Mat src = cv::imread("source_image.jpg");
    if (src.empty()) {
        std::cout << "Could not open or find the image" << std::endl;
        return -1;
    }

    // ���÷���任��Դ���Ŀ���
    cv::Point2f srcTri[3];
    srcTri[0] = cv::Point2f(0, 0);
    srcTri[1] = cv::Point2f(src.cols - 1, 0);
    srcTri[2] = cv::Point2f(0, src.rows - 1);

    cv::Point2f dstTri[3];
    dstTri[0] = cv::Point2f(0, src.rows * 0.33);
    dstTri[1] = cv::Point2f(src.cols * 0.85, src.rows * 0.25);
    dstTri[2] = cv::Point2f(src.cols * 0.15, src.rows * 0.7);

    // �������任����
    cv::Mat warp_mat = cv::getAffineTransform(srcTri, dstTri);

    // ��ԭʼͼ��Ӧ�÷���任
    cv::Mat warp_dst = cv::Mat::zeros(src.rows, src.cols, src.type());
    cv::warpAffine(src, warp_dst, warp_mat, warp_dst.size());

    // ��ʾ���
    cv::imshow("Original Image", src);
    cv::imshow("Warped Image", warp_dst);
    cv::waitKey(0);
    return 0;
}

C_OpenCV::C_OpenCV(string file)
{
    iniFile = file;
    //ini_manager = IniManager(iniFile);
    qrDecoder = QRCodeDetector();
    tk = time(NULL);
    Init();
}

void C_OpenCV::Init()
{
    IniManager ini_manager(iniFile);
    //cout << ini_manager["video"]["mediaType"];
    dstTri[0].x = ini_manager["affine"].toInt("dstX1");
    dstTri[0].y = ini_manager["affine"].toInt("dstY1");

    dstTri[1].x = ini_manager["affine"].toInt("dstX2");
    dstTri[1].y = ini_manager["affine"].toInt("dstY2");

    dstTri[2].x = ini_manager["affine"].toInt("dstX3");
    dstTri[2].y = ini_manager["affine"].toInt("dstY3");

    mediaSource = ini_manager["video"]["videosrc"];
    camNo = ini_manager["video"].toInt("camera");
    mediaType = ini_manager["video"].toInt("mediaType");
    cameraW = ini_manager["video"].toInt("cameraW");
    cameraH = ini_manager["video"].toInt("cameraH");

    scale = ini_manager["affine"].toDouble("scale");

    strQR1 = ini_manager["QRCode"]["strQR1"];
    strQR2 = ini_manager["QRCode"]["strQR2"];
    strQR3 = ini_manager["QRCode"]["strQR3"];

    OpenMedia();
}

//�����������ͼ���С
bool C_OpenCV::OpenMedia()
{
    //���������Ƶ��
    if (mediaType == 0) {
        capture = VideoCapture(camNo);
    }
    else {
        capture = VideoCapture(mediaSource);
    }
    if (capture.isOpened())
    {
        if (mediaType == 0)
        {
            capture.set(cv::CAP_PROP_FRAME_WIDTH, cameraW);
            capture.set(cv::CAP_PROP_FRAME_HEIGHT, cameraH);

        }
        if (!bSetSubPic)
        {
            SetSubPic();
        }
        return true;
    }
    return false;
}

void C_OpenCV::PrepairCamera()
{
    //wstring text = L"�뽫��ͷ��׼��������,Ȼ�󰴡�q���˳�����,���߰����������";
    while (true)
    {
        if (capture.read(image))
        {
            cv::putText(image, "press ��q�� for exit, or any key for continue",
                Point(30, 30), FONT_HERSHEY_SIMPLEX, 1, Scalar(0, 0, 255), 3);
        }
        DrawCenter();
        //imshow("������ͷ", image);
        int c = waitKey(30);
        if (c == 'q')
            exit(0);
        else if (c != -1)
            break;
    }
}

//����ͼ���С������ָ���ͼ���С
void C_OpenCV::SetSubPic()
{
    if (bSetSubPic)
        return;
    //PrepairCamera();
    if (capture.read(image))
    {
        // ��ȡͼ��Ĵ�С
        cv::Size size = image.size();

        // ��ȡͼ��Ŀ��Ⱥ͸߶�
        w = size.width;
        h = size.height;
        subPicW = (int)(w * scale);
        subPicH = (int)(h * scale);
        roi[0] = Rect(0, 0, subPicW, subPicH);
        roi[1] = Rect(w - subPicW, 0, subPicW, subPicH);
        roi[2] = Rect(0, h - subPicH, subPicW, subPicH);
#ifndef AFFINE
        roi[3] = Rect(w - subPicW, h - subPicH, subPicW, subPicH);
#endif
        
        printf("\nw,h,subPicW,subPicH:%d,%d,%d,%d\n", w, h, subPicW, subPicH);

        bSetSubPic = true;
    }
}

void C_OpenCV::DrawCenter()
{
    Point center(w / 2, h / 2);
    // ����ֱ��
    cv::line(image,
        cv::Point(center.x, center.y - 30),
        cv::Point(center.x, center.y + 30),
        cv::Scalar(0, 255, 0), // ��ɫ����
        2); // ������ϸ

// ��ˮƽ��
    cv::line(image,
        cv::Point(center.x - 30, center.y),
        cv::Point(center.x + 30, center.y),
        cv::Scalar(0, 0, 255), // ��ɫ����
        2); // ������ϸ
    imshow("image", image);
}

//����ת������
void C_OpenCV::CaliTransMat()
{
    Mat frame, lastFrame;
    bool bGotNewFrame = false;

    bGotNewFrame = false;
    //��ȡ����һ֡ͼ��
    while (capture.read(image))
    {
        bGotNewFrame = true;
        if (mediaType == 0)
            break;
        //lastFrame = frame;
    }
    if (!bGotNewFrame)
        return;
    /*
    Point center(w / 2, h / 2);
    // ����ֱ��
    cv::line(image,
        cv::Point(center.x, center.y - 30),
        cv::Point(center.x, center.y + 30),
        cv::Scalar(0, 255, 0), // ��ɫ����
        2); // ������ϸ

// ��ˮƽ��
    cv::line(image,
        cv::Point(center.x - 30, center.y),
        cv::Point(center.x + 30, center.y),
        cv::Scalar(0, 0, 255), // ��ɫ����
        2); // ������ϸ
    imshow("image", image);
    */
    if (!bSetSubPic)
        return;


    try
    {
        for (int i = 0; i < QRCODECNT; i++)
        {
            Mat img = image(roi[i]);
            imshow(to_string(i), img);
            vector<Point> qrPoints;
            string qrStr = qrDecoder.detectAndDecode(img, qrPoints);
            if (qrStr.length() > 0) {
                if (i == 0)
                {
                    srcTri[0].x = qrPoints[0].x;
                    srcTri[0].y = qrPoints[0].y;
                    printf("point1:%d,%d\n", qrPoints[0].x, qrPoints[0].y);
                }
                else if (i == 1)
                {
                    srcTri[1].x = qrPoints[1].x + w - subPicW;
                    srcTri[1].y = qrPoints[1].y;
                    printf("point2:%d,%d\n", qrPoints[1].x, qrPoints[1].y);
                }
                else if (i == 2)
                {
                    srcTri[i].x = qrPoints[3].x;
                    srcTri[i].y = qrPoints[3].y + h - subPicH;
                    printf("point3:%d,%d\n", qrPoints[3].x, qrPoints[3].y);
                }
                else if (i == 3)//���ĸ���ά�룬͸�ӱ任ʱ��Ч
                {
                    srcTri[1].x = qrPoints[2].x + w - subPicW;
                    srcTri[i].y = qrPoints[2].y + h - subPicH;
                    printf("point4:%d,%d\n", qrPoints[2].x, qrPoints[2].y);
                }



                /*
                // ������ά�������ֱ��
                cv::Mat img = image.clone();
                for (int i = 0; i < corners.size(); i++) {
                    cv::line(img, corners[i], corners[(i + 1) % corners.size()], cv::Scalar(0, 255, 0), 3);
                }
                cv::imshow("Straight QR Code", straight_qrcode);
                cv::imshow("Detected QR Code", img);
                cv::waitKey(0);*/
            }
            else {
                std::cout << "No QR Code detected." << std::endl;
                return;
            }
        }
        transMat = getAffineTransform(srcTri, dstTri);

        cout << "srcTri\n";
        printf("%f,%f,%f,%f,%f,%f\n", srcTri[0].x, srcTri[0].y, srcTri[1].x, srcTri[1].y, srcTri[2].x, srcTri[2].y);
        bGotTransMat = true;
    }
    catch (const std::exception&)
    {

    }

    
    destroyAllWindows();
}

void C_OpenCV::warpAffineAFrame()
{
    if (!bGotTransMat) {
        return;
    }
    bool bGotNewFrame = false;
    //��ȡ����һ֡ͼ��
    while (capture.read(image))
    {
        bGotNewFrame = true;
        if (mediaType == 0) {
            break;
        }
        //lastFrame = frame;
    }
    if (!bGotNewFrame) {
        return;
    }
    cv::Mat warp_dst = cv::Mat::zeros(h, w, image.type());
    warpAffine(image, warp_dst, transMat, warp_dst.size());

    imshow("image", image);
    imshow("warp_dst", warp_dst);
}